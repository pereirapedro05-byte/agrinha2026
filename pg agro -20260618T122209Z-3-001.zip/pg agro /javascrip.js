document.addEventListener("DOMContentLoaded", () => {
    
    // 1. Efeito de Animação de Números (Contadores)
    const counters = document.querySelectorAll('.counter');
    
    const runCounters = () => {
        counters.forEach(counter => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const increment = target / 50; // Velocidade da animação

            if (count < target) {
                counter.innerText = Math.ceil(count + increment);
                setTimeout(runCounters, 30);
            } else {
                counter.innerText = target;
            }
        });
    };

    // Ativa os contadores quando o usuário rolar até a seção de dados
    const statsSection = document.querySelector('.stats-section');
    const observer = new IntersectionObserver((entries) => {
        if(entries[0].isIntersecting) {
            runCounters();
            observer.disconnect(); // Roda apenas uma vez
        }
    }, { threshold: 0.5 });

    observer.observe(statsSection);

    // 2. Validação e Envio do Formulário de Contato
    const form = document.getElementById('agroForm');
    const feedback = document.getElementById('formFeedback');

    form.addEventListener('submit', (e) => {
        e.preventDefault(); // Evita o recarregamento da página

        const nome = document.getElementById('nome').value;

        // Simulando envio bem-sucedido
        feedback.innerText = `Obrigado pelo contato, ${nome}! Nossa equipe técnica retornará em breve.`;
        feedback.className = "success";
        
        // Limpa o formulário
        form.reset();
    });
});
